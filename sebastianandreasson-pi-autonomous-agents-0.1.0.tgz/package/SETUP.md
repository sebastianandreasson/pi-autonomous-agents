# Setup Guide

This file is written for an autonomous coding agent that has been asked to set up `@sebastianandreasson/pi-autonomous-agents` in the current repository.

## Goal

Install and configure the package so this repo can run:

- `pi-harness once`
- `pi-harness run`
- `pi-harness report`
- `pi-harness visual-once`

Do not stop after installing the dependency. Complete the repo-local setup as well.

## Required End State

When you are done, the consuming repo should contain:

- `pi.config.json`
- `TODOS.md` if the repo does not already have one
- `pi/DEVELOPER.md`
- `pi/TESTER.md`
- package scripts for the harness commands
- `.gitignore` entries for harness runtime/output files

If the repo already has equivalent files, update them instead of creating duplicates.

## Setup Steps

1. Install the package.

Preferred command:

```bash
npm install -D @sebastianandreasson/pi-autonomous-agents
```

If the repo uses another package manager already, use the repo-native equivalent instead.

2. Create `pi.config.json`.

- Start from `node_modules/@sebastianandreasson/pi-autonomous-agents/templates/pi.config.example.json`.
- Copy it into the repo root as `pi.config.json`.
- Update it for this repo:
  - `taskFile`: usually `TODOS.md`
  - `developerInstructionsFile`: `pi/DEVELOPER.md`
  - `testerInstructionsFile`: `pi/TESTER.md`
  - `testCommand`: a fast bounded verification command for this repo
  - `visualCaptureCommand`: only if this repo has a real screenshot capture flow
  - `models` / `piModel` / `visualReviewModel` / `roleModels`: configure the models actually available in this environment

3. Create role instruction files.

- Copy `node_modules/@sebastianandreasson/pi-autonomous-agents/templates/DEVELOPER.md` to `pi/DEVELOPER.md`.
- Copy `node_modules/@sebastianandreasson/pi-autonomous-agents/templates/TESTER.md` to `pi/TESTER.md`.
- Customize both files for the repo:
  - name the actual product/app
  - describe the real verification expectations
  - mention project-specific constraints, startup flow, or directories
  - keep the harness workflow intact

4. Ensure `TODOS.md` exists.

- If the repo already uses a task file, keep it.
- Otherwise create a minimal `TODOS.md` with at least one phase heading and one unchecked actionable checkbox.

Minimal example:

```md
## Phase 1

- [ ] Define the first real task for this repo
```

5. Add package scripts.

Add these scripts to the consuming repo `package.json`, adapting only if necessary:

```json
{
  "scripts": {
    "pi:mock": "PI_CONFIG_FILE=pi.config.json PI_TRANSPORT=mock PI_TEST_CMD= pi-harness once",
    "pi:once": "PI_CONFIG_FILE=pi.config.json pi-harness once",
    "pi:run": "PI_CONFIG_FILE=pi.config.json pi-harness run",
    "pi:report": "PI_CONFIG_FILE=pi.config.json pi-harness report",
    "pi:visual:once": "PI_CONFIG_FILE=pi.config.json pi-harness visual-once"
  }
}
```

If the repo already has scripts with those names, update them instead of duplicating.

6. Update `.gitignore`.

Add the entries from:

- `node_modules/@sebastianandreasson/pi-autonomous-agents/templates/gitignore.fragment`

Merge them into the repo `.gitignore` without duplicating existing lines.

7. Pick a safe default verification command.

Important:

- `testCommand` must be fast and bounded.
- Do not use a long end-to-end happy-path spec as the inner-loop default.
- Prefer smoke tests or a narrow targeted command.

If the repo does not yet have a good smoke command, set `testCommand` to an empty string and note that setup is incomplete.

8. Configure models conservatively.

Recommended pattern:

- local model for `developer`
- local model for `developerRetry`
- local model for `developerFix`
- local or slightly stronger model for `tester`
- stronger frontier model for `visualReview` only if available

Example shape:

```json
{
  "piModel": "local/dev-model",
  "visualReviewModel": "cloud/vision-model",
  "roleModels": {
    "developer": "local/dev-model",
    "developerRetry": "local/dev-model",
    "developerFix": "local/dev-model",
    "tester": "local/tester-model",
    "testerCommit": "local/tester-model",
    "visualReview": "cloud/vision-model"
  }
}
```

9. Validate the setup.

Run at least:

```bash
PI_CONFIG_FILE=pi.config.json pi-harness once
```

If the repo is not ready for a real run yet, at minimum run:

```bash
PI_CONFIG_FILE=pi.config.json PI_TRANSPORT=mock PI_TEST_CMD= pi-harness once
```

If setup validation fails, fix the config rather than leaving a half-configured repo.

## Agent Rules

- Reuse existing repo conventions where possible.
- Do not replace project-specific instructions with generic text if good instructions already exist.
- Do not invent fake test commands or model endpoints.
- Do not enable visual review unless the repo actually has a usable capture command and model config.
- Keep changes minimal and local to harness setup.

## What To Report Back

When setup is complete, report:

- which files were created or updated
- which verification command was configured
- whether visual review was enabled
- which roles were mapped to which models
- whether validation was run successfully
